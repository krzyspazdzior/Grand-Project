twoj bios został zrescriptowany!! komputer wyjebie w powietrze chyba 
ze przelejesz 5zl blik na numer 731 231 737 to wtedy sztama pozdro